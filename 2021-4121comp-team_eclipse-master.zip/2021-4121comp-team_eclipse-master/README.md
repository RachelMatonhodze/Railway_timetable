Application entry point: src/DataLoader.java

[Sprint Planning Log](https://docs.google.com/document/d/1krqAcJ18U3D53FMoibH7DxSqMPWv8_ZIioubt-LN6zI)

[Skills Assessment](https://docs.google.com/document/d/1u8B594i3o5zuwvKYDuSFUJJE6fXW7WADvIeBNv_4WpE/edit)

[Review and Retrospective Log](https://docs.google.com/document/d/14lKmRPkoQZQYULeb9qNiKj_WiMqpfnQj3UgEP3-gmfc)

[Client Meeting Log](https://docs.google.com/document/d/1IBY7bRdBUZ7cCFM1cEQLZrnpgNIMGZ2-cVUKwtx3lZs)

[Working Agreement](https://docs.google.com/document/d/1hq64R9xyp2LZZ4JY2fANQSvPL9RVavPtzHvcq1xhhvQ)

[Use-Case Descriptions](https://docs.google.com/document/d/1Z-9WTeOY3MqFSEbFVb5P4koCRqSPgZdQYtWfeCfmZh0/edit)
